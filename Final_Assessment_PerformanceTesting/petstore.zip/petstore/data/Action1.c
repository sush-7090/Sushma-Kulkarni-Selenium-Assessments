Action1()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t29.inf", 
		"Mode=HTTP", 
		LAST);

	web_custom_request("gsatlasr3dvtlsca2026q2", 
		"URL=http://ocsp.globalsign.com/ca/gsatlasr3dvtlsca2026q2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t30.inf", 
		"Mode=HTTP", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x01\\xB3\\xDD\\xD9\\xFE\\xFE\\x04\\xB1\\xF1\\x05\\xA6\\x8F\\x84Af\\xA9", 
		LAST);

	web_custom_request("gsatlasr3dvtlsca2026q2_2", 
		"URL=http://ocsp.globalsign.com/ca/gsatlasr3dvtlsca2026q2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t31.inf", 
		"Mode=HTTP", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x01\\xB3\\xDD\\xD9\\xFE\\xFE\\x04\\xB1\\xF1\\x05\\xA6\\x8F\\x84Af\\xA9", 
		LAST);

	web_custom_request("gsatlasr3dvtlsca2026q2_3", 
		"URL=http://ocsp.globalsign.com/ca/gsatlasr3dvtlsca2026q2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t32.inf", 
		"Mode=HTTP", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x01\\xB3\\xDD\\xD9\\xFE\\xFE\\x04\\xB1\\xF1\\x05\\xA6\\x8F\\x84Af\\xA9", 
		LAST);

	lr_think_time(4);

	web_url("splash.gif", 
		"URL=https://jpetstore.aspectran.com/images/splash.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t33.inf", 
		LAST);

	web_url("logo-topbar.gif", 
		"URL=https://jpetstore.aspectran.com/images/logo-topbar.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t34.inf", 
		LAST);

	web_url("update.xml", 
		"URL=https://aus5.mozilla-backup.org/update/6/Firefox/156.0.1/20260921121718/WINNT_x86_64-msvc-x64/en-US/release/Windows_NT%252010.0.0.0.26200.9550%2520(x64)/ISET%3ASSE4_2%2CMEM%3A7835/default/default/update.xml?force=1", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t35.inf", 
		"Mode=HTTP", 
		LAST);

	web_websocket_send("ID=2", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790836606237\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 2 received buffer WebSocketReceive0*/

	lr_think_time(5);

	lr_start_transaction("SelectCatagory");

	web_url("DOGS", 
		"URL=https://jpetstore.aspectran.com/categories/DOGS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t36.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("SelectCatagory",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("ProductId");

	web_url("K9-BD-01", 
		"URL=https://jpetstore.aspectran.com/products/K9-BD-01", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/categories/DOGS", 
		"Snapshot=t37.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("ProductId",LR_AUTO);

	lr_start_transaction("AddCart");

	web_url("Add to Cart", 
		"URL=https://jpetstore.aspectran.com/cart/addItemToCart?itemId=EST-33", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/products/K9-BD-01", 
		"Snapshot=t38.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("AddCart",LR_AUTO);

	lr_start_transaction("CheckOut");

	web_url("Proceed to Checkout", 
		"URL=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/cart/viewCart", 
		"Snapshot=t39.inf", 
		"Mode=HTTP", 
		LAST);

	web_submit_data("signon", 
		"Action=https://jpetstore.aspectran.com/account/signon", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/signonForm?referer=/order/newOrderForm", 
		"Snapshot=t40.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=referer", "Value=/order/newOrderForm", ENDITEM, 
		"Name=username", "Value=j2ee", ENDITEM, 
		"Name=password", "Value=j2ee", ENDITEM, 
		LAST);

	web_url("banner_dogs.gif", 
		"URL=https://jpetstore.aspectran.com/images/banner_dogs.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t41.inf", 
		LAST);

	lr_end_transaction("CheckOut",LR_AUTO);

	lr_think_time(16);

	lr_start_transaction("Continue");

	web_submit_data("newOrder", 
		"Action=https://jpetstore.aspectran.com/order/newOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t42.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentForm", "Value=true", ENDITEM, 
		"Name=billingForm", "Value=true", ENDITEM, 
		"Name=cardType", "Value=Visa", ENDITEM, 
		"Name=creditCard", "Value=999999999999999", ENDITEM, 
		"Name=expiryDate", "Value=12/2019", ENDITEM, 
		"Name=billToFirstName", "Value=Test", ENDITEM, 
		"Name=billToLastName", "Value=User", ENDITEM, 
		"Name=billAddress1", "Value=123 Test St", ENDITEM, 
		"Name=billAddress2", "Value=123 Test St", ENDITEM, 
		"Name=billCity", "Value=Testville", ENDITEM, 
		"Name=billState", "Value=CA", ENDITEM, 
		"Name=billZip", "Value=10001", ENDITEM, 
		"Name=billCountry", "Value=US", ENDITEM, 
		LAST);

	lr_end_transaction("Continue",LR_AUTO);

	lr_start_transaction("Confirm");

	web_submit_data("submitOrder", 
		"Action=https://jpetstore.aspectran.com/order/submitOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrder", 
		"Snapshot=t43.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=confirmed", "Value=true", ENDITEM, 
		LAST);

	lr_end_transaction("Confirm",LR_AUTO);

	return 0;
}